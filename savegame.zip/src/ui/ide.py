import pygame
import pygame_gui
import threading
import time
import sys
import traceback
from src.config import *
from src.core.farm import Farm
from src.core.api import DroneAPI
from src.core.storage import SaveManager
from src.ui.visuals import get_visual_manager, Tween, ease_out_back

class GameIDE:
    def __init__(self):
        pygame.init()
        self.window = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
        pygame.display.set_caption("Farm Game - Modular OOP Version")
        
        self.clock = pygame.time.Clock()
        self.running = True
        
        self.ui_manager = pygame_gui.UIManager((SCREEN_WIDTH, SCREEN_HEIGHT))
        
        # --- 布局规划 (总高度 600) ---
        # 1. 代码编辑器: 0 ~ 380 (高度 380)
        # 2. 背包显示: 380 ~ 440 (高度 60)
        # 3. 存档按钮: 440 ~ 480 (高度 40)
        # 4. 控制台: 480 ~ 550 (高度 70)
        # 5. 运行按钮: 550 ~ 600 (高度 50)

        # --- 1. 代码编辑器 ---
        init_code = """
# 自动种植与收割脚本
while True:
    drone.plant("carrot")
    if drone.harvest():
        print("Got one!")
    
    drone.move("East")
    if drone.get_pos()[0] >= 9:
        for _ in range(9):
             drone.move("West")
             drone.move("South")
"""
        self.code_editor = pygame_gui.elements.UITextEntryBox(
            relative_rect=pygame.Rect((GAME_AREA_WIDTH, 0), (UI_AREA_WIDTH, 380)),
            initial_text=init_code.strip(),
            manager=self.ui_manager
        )
        
        # --- 2. 背包显示 ---
        self.inventory_display = pygame_gui.elements.UITextBox(
            relative_rect=pygame.Rect((GAME_AREA_WIDTH, 380), (UI_AREA_WIDTH, 60)),
            html_text="<b>Inventory:</b> Empty",
            manager=self.ui_manager
        )

        # --- 3. 存档/读档按钮 ---
        self.btn_save = pygame_gui.elements.UIButton(
            relative_rect=pygame.Rect((GAME_AREA_WIDTH, 440), (UI_AREA_WIDTH // 2 - 5, 40)),
            text='Save',
            manager=self.ui_manager
        )
        
        self.btn_load = pygame_gui.elements.UIButton(
            relative_rect=pygame.Rect((GAME_AREA_WIDTH + UI_AREA_WIDTH // 2 + 5, 440), (UI_AREA_WIDTH // 2 - 5, 40)),
            text='Load',
            manager=self.ui_manager
        )
        
        # --- 4. 控制台输出 ---
        self.console_output = pygame_gui.elements.UITextBox(
            relative_rect=pygame.Rect((GAME_AREA_WIDTH, 480), (UI_AREA_WIDTH, 70)),
            html_text="Console Ready...<br>",
            manager=self.ui_manager
        )
        
        # --- 5. 运行按钮 ---
        self.run_button = pygame_gui.elements.UIButton(
            relative_rect=pygame.Rect((GAME_AREA_WIDTH, 550), (UI_AREA_WIDTH, 50)),
            text='RUN CODE (CTRL+ENTER)',
            manager=self.ui_manager
        )

        self.farm = Farm()
        self.drone = DroneAPI(self.farm, self.print_to_console)
        self.thread = None
        
        # --- Visual Integration ---
        self.visual_manager = get_visual_manager()
        self.visual_manager.load_assets() # Ensure assets are ready

    def print_to_console(self, text):
        self.console_output.append_html_text(f"{text}<br>")
        if self.console_output.scroll_bar:
            self.console_output.scroll_bar.scroll_position = self.console_output.scroll_bar.bottom_limit

    def update_inventory_ui(self):
        text = "<b>Inventory:</b> "
        if not self.drone.inventory:
            text += "Empty"
        else:
            items = [f"{k}: {v}" for k, v in self.drone.inventory.items()]
            text += " | ".join(items)
        self.inventory_display.set_text(text)

    def run_user_code(self):
        code = self.code_editor.get_text()
        
        if self.thread and self.thread.is_alive():
            self.drone._stop_flag = True
            self.thread.join(timeout=1.0)
        
        self.drone._stop_flag = False
        self.console_output.set_text("")
        self.print_to_console("<font color='#00FF00'>--- Script Start ---</font>")

        def target():
            env = {
                'drone': self.drone,
                'time': time,
                'print': self.drone.log
            }
            try:
                exec(code, env)
            except Exception as e:
                self.print_to_console(f"<font color='#FF0000'>Error: {e}</font>")
                traceback.print_exc()

        self.thread = threading.Thread(target=target, daemon=True)
        self.thread.start()

    def save_game_action(self):
        current_code = self.code_editor.get_text()
        if SaveManager.save_game(self.farm, self.drone, current_code):
            self.print_to_console("<font color='#FFFF00'>Game Saved!</font>")

    def load_game_action(self):
        loaded_code = SaveManager.load_game(self.farm, self.drone)
        if loaded_code is not None:
            self.code_editor.set_text(loaded_code)
            self.print_to_console("<font color='#FFFF00'>Game Loaded!</font>")
            self.update_inventory_ui()

    def process_drone_events(self):
        while self.drone.events:
            event = self.drone.events.pop(0)
            grid_x, grid_y = event.get("x"), event.get("y")
            screen_x = 50 + grid_x * GRID_SIZE + GRID_SIZE // 2
            screen_y = 50 + grid_y * GRID_SIZE + GRID_SIZE // 2

            if event["type"] == "move":
                # Smooth move for the visual representation
                self.visual_manager.add_tween(Tween(self.drone, "visual_x", float(grid_x), 0.2))
                self.visual_manager.add_tween(Tween(self.drone, "visual_y", float(grid_y), 0.2))
            
            elif event["type"] == "plant":
                self.visual_manager.spawn_poof(screen_x, screen_y)
                self.visual_manager.spawn_floating_text(screen_x, screen_y - 20, f"Planted {event['name']}", (100, 200, 100))
            
            elif event["type"] == "harvest":
                self.visual_manager.spawn_spark(screen_x, screen_y)
                self.visual_manager.spawn_floating_text(screen_x, screen_y - 20, f"+1 {event['name']}", (255, 215, 0))

    def draw_game_area(self):
        surface = pygame.Surface((GAME_AREA_WIDTH, SCREEN_HEIGHT))
        surface.fill(COLOR_GAME_BG)
        
        offset = 50
        
        # Draw Grass/Dirt Background using procedural tiles
        tile_img = self.visual_manager.get_asset("tile_grass")
        for y in range(self.farm.height):
            for x in range(self.farm.width):
                rect_x = offset + x * GRID_SIZE
                rect_y = offset + y * GRID_SIZE
                surface.blit(tile_img, (rect_x, rect_y))
                pygame.draw.rect(surface, COLOR_GRID, (rect_x, rect_y, GRID_SIZE, GRID_SIZE), 1)
                
                crop = self.farm.grid[y][x]
                if crop:
                    # Get stage (1-4)
                    growth_ratio = crop.current_growth / crop.max_growth if crop.max_growth > 0 else 0
                    stage = min(4, int(growth_ratio * 3) + 1)
                    asset_name = f"crop_{crop.name.lower()}_stage{stage}"
                    crop_img = self.visual_manager.get_asset(asset_name)
                    
                    crop_rect = crop_img.get_rect(center=(rect_x + GRID_SIZE // 2, rect_y + GRID_SIZE // 2))
                    surface.blit(crop_img, crop_rect)

        # Draw Drone with smooth coords
        d_visual_x = offset + self.drone.visual_x * GRID_SIZE
        d_visual_y = offset + self.drone.visual_y * GRID_SIZE
        drone_img = self.visual_manager.get_asset("drone_idle")
        drone_rect = drone_img.get_rect(topleft=(d_visual_x - 7, d_visual_y - 7)) # Adjust slightly for size
        surface.blit(drone_img, drone_rect)
        
        # Draw Particles
        self.visual_manager.draw(surface)
        
        self.window.blit(surface, (0, 0))

    def run(self):
        while self.running:
            time_delta = self.clock.tick(60) / 1000.0
            
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.running = False
                
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_RETURN and (pygame.key.get_mods() & pygame.KMOD_CTRL):
                        self.run_user_code()

                if event.type == pygame_gui.UI_BUTTON_PRESSED:
                    if event.ui_element == self.run_button:
                        self.run_user_code()
                    elif event.ui_element == self.btn_save:
                        self.save_game_action()
                    elif event.ui_element == self.btn_load:
                        self.load_game_action()
                
                self.ui_manager.process_events(event)
            
            self.ui_manager.update(time_delta)
            self.farm.update(time_delta)
            self.visual_manager.update(time_delta)
            self.process_drone_events()
            self.update_inventory_ui()
            
            self.window.fill(COLOR_BG)
            self.draw_game_area()
            self.ui_manager.draw_ui(self.window)
            pygame.display.flip()

        if self.thread:
            self.drone._stop_flag = True
        pygame.quit()
        sys.exit()
