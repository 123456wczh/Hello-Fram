# --- 配置参数 ---
SCREEN_WIDTH = 1000
SCREEN_HEIGHT = 600
GAME_AREA_WIDTH = 600
UI_AREA_WIDTH = 400
GRID_SIZE = 50

# 颜色定义 (Pleasant & Vibrant Theme)
COLOR_BG = (245, 247, 250)      # Soft light gray/blue background
COLOR_GAME_BG = (255, 255, 255)   # Pure white for the farm area
COLOR_GRID = (230, 235, 240)      # Subtle grid lines
COLOR_UI_PANEL = (240, 244, 248)  # Slightly darker UI area
COLOR_ACCENT = (74, 144, 226)     # Friendly blue accent

# 存档文件
SAVE_FILE = "savegame.json"

# 其他平衡常数
DRONE_MOVE_DELAY = 0.2
GRID_WIDTH = 10
GRID_HEIGHT = 10
