import pygame
import os
import sys

# Initialize pygame strictly for drawing
pygame.init()

# --- Configuration ---
ASSET_SIZE = 64
PARTICLE_SIZE = 32
ASSET_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), "assets")

# --- Palette V2: Curated Soft/Modern Colors ---
PALETTE = {
    # Crops
    "carrot":     (255, 127, 80),   # Coral
    "carrot_dark":(255, 99, 71),    # Tomato (shadow)
    "leaf":       (144, 238, 144),  # Light Green
    "leaf_dark":  (60, 179, 113),   # Medium Sea Green
    
    "pumpkin":    (255, 165, 0),    # Orange
    "pumpkin_d":  (210, 105, 30),   # Chocolate
    
    "sunflower":  (255, 215, 0),    # Gold
    "suncenter":  (139, 69, 19),    # Saddle Brown
    
    # Drone
    "drone_body": (255, 255, 255),  # White
    "drone_acc":  (50, 173, 239),   # Soft Blue
    "drone_dark": (200, 200, 210),  # Light Gray shadow
    
    # Environment
    "grass_bg":   (235, 248, 225),  # Very pale green
    "grass_acc":  (190, 220, 180),  # Subtle grass blades
    "dirt_bg":    (245, 222, 179),  # Wheat
    "dirt_acc":   (210, 180, 140),  # Tan
    
    # VFX
    "shadow":     (0, 0, 0, 40),    # Transparent Black
    "gold":       (255, 223, 0),    # Golden Yellow
    "sparkle":    (255, 250, 205),  # Lemon Chiffon
}

class AssetGenerator:
    """
    V2 Generator: Focus on simple shapes, soft shadows, and clean proportions.
    """

    @staticmethod
    def _create_surface(size=ASSET_SIZE):
        s = pygame.Surface((size, size), pygame.SRCALPHA)
        return s

    @staticmethod
    def _draw_shadow(surf, scale=1.0):
        # Universal drop shadow for "floating" effect
        rect = pygame.Rect(16, 48, 32 * scale, 12 * scale)
        rect.centerx = 32
        pygame.draw.ellipse(surf, PALETTE["shadow"], rect)

    @staticmethod
    def draw_carrot(stage: int) -> pygame.Surface:
        surf = AssetGenerator._create_surface()
        AssetGenerator._draw_shadow(surf)
        
        # Draw Body (Rounded Triangle mostly buried)
        # Stage 1-4 impacts leaf size mostly
        
        # Leaves
        leaf_color = PALETTE["leaf"]
        leaf_dark = PALETTE["leaf_dark"]
        
        center_x, bottom_y = 32, 52
        
        if stage >= 1:
            # Small Sprouts
            h = 6 + stage * 4
            # Draw back leaves (darker)
            pygame.draw.ellipse(surf, leaf_dark, (center_x - 6, bottom_y - h - 2, 6, h))
            pygame.draw.ellipse(surf, leaf_dark, (center_x + 2, bottom_y - h - 2, 6, h))
            # Front leaves
            pygame.draw.ellipse(surf, leaf_color, (center_x - 4, bottom_y - h, 8, h + 2))

        # Body (Only visible tip if fully grown)
        if stage == 4:
             pygame.draw.circle(surf, PALETTE["carrot"], (32, 52), 6)
             pygame.draw.circle(surf, PALETTE["carrot_dark"], (30, 52), 2) # Texture dot

        return surf

    @staticmethod
    def draw_pumpkin(stage: int) -> pygame.Surface:
        surf = AssetGenerator._create_surface()
        AssetGenerator._draw_shadow(surf, scale=1.2)
        
        if stage < 4:
            # Growing green sphere
            r = 5 + stage * 5
            pygame.draw.circle(surf, PALETTE["leaf_dark"], (32, 45), r)
            pygame.draw.circle(surf, PALETTE["leaf"], (30, 43), r//2) # Highlight
        else:
            # Mature Pumpkin
            # Draw back lobes
            pygame.draw.circle(surf, PALETTE["pumpkin_d"], (22, 40), 12)
            pygame.draw.circle(surf, PALETTE["pumpkin_d"], (42, 40), 12)
            # Front lobe
            pygame.draw.circle(surf, PALETTE["pumpkin"], (32, 42), 14)
            # Highlight
            pygame.draw.ellipse(surf, (255, 200, 100), (28, 38, 8, 6))
            # Stem
            pygame.draw.rect(surf, PALETTE["leaf_dark"], (30, 26, 4, 8), border_radius=2)

        return surf

    @staticmethod
    def draw_sunflower(stage: int) -> pygame.Surface:
        surf = AssetGenerator._create_surface()
        AssetGenerator._draw_shadow(surf)
        
        # Stem
        pygame.draw.rect(surf, (80, 160, 80), (31, 35, 2, 20))
        
        if stage < 4:
            # Bud
            pygame.draw.circle(surf, (100, 200, 100), (32, 35), 4 + stage * 3)
        else:
            # Flower
            cx, cy = 32, 32
            # Petals
            for i in range(0, 360, 45):
                 # Polar coord for petals
                 import math
                 rad = math.radians(i)
                 px = cx + math.cos(rad) * 12
                 py = cy + math.sin(rad) * 12
                 pygame.draw.circle(surf, PALETTE["sunflower"], (px, py), 9)
            
            # Center
            pygame.draw.circle(surf, PALETTE["suncenter"], (cx, cy), 13)
            # Seeds detail
            pygame.draw.circle(surf, (100, 50, 10), (cx-4, cy-4), 2)
            pygame.draw.circle(surf, (100, 50, 10), (cx+4, cy+4), 2)
            pygame.draw.circle(surf, (100, 50, 10), (cx-4, cy+4), 2)
            pygame.draw.circle(surf, (100, 50, 10), (cx+4, cy-4), 2)

        return surf

    @staticmethod
    def draw_drone(mode="idle") -> pygame.Surface:
        surf = AssetGenerator._create_surface()
        # Drop Shadow (Stronger)
        AssetGenerator._draw_shadow(surf, scale=1.1)

        # 1. Rotors (X-Configuration)
        # Draw arms
        c_arm = (220, 220, 220)
        pygame.draw.line(surf, c_arm, (16, 16), (48, 48), 3)
        pygame.draw.line(surf, c_arm, (48, 16), (16, 48), 3)

        # Draw Rotors (Blurred Circles)
        rotor_c = (200, 230, 255, 100)
        for rx, ry in [(16,16), (48,16), (16,48), (48,48)]:
            pygame.draw.circle(surf, (180, 180, 180), (rx, ry), 2) # Motor
            pygame.draw.circle(surf, rotor_c, (rx, ry), 10) # Blade blur

        # 2. Main Body (Sleek Rounded Square)
        body_rect = pygame.Rect(24, 24, 16, 16)
        pygame.draw.rect(surf, PALETTE["drone_body"], body_rect, border_radius=6)
        
        # 3. Eye / Core
        eye_color = PALETTE["drone_acc"] if mode == "idle" else (255, 100, 100)
        pygame.draw.circle(surf, eye_color, (32, 32), 4)
        
        # 4. Highlight
        pygame.draw.circle(surf, (255, 255, 255), (28, 28), 2)

        return surf

    @staticmethod
    def draw_shrub_dead() -> pygame.Surface:
        surf = AssetGenerator._create_surface()
        c = (160, 130, 110)
        pygame.draw.line(surf, c, (32, 50), (20, 30), 2)
        pygame.draw.line(surf, c, (32, 50), (44, 35), 2)
        pygame.draw.circle(surf, c, (32, 52), 4)
        return surf

    @staticmethod
    def draw_tile(kind="dirt") -> pygame.Surface:
        surf = AssetGenerator._create_surface()
        if kind == "dirt":
            surf.fill(PALETTE["dirt_bg"])
            # Subtle pattern
            pygame.draw.circle(surf, PALETTE["dirt_acc"], (10, 10), 4)
            pygame.draw.circle(surf, PALETTE["dirt_acc"], (40, 50), 6)
        elif kind == "wet":
            surf.fill(PALETTE["dirt_acc"]) # Darker
        elif kind == "grass":
            surf.fill(PALETTE["grass_bg"])
            # Cute grass Tuft
            c = PALETTE["grass_acc"]
            pygame.draw.arc(surf, c, (10, 20, 10, 10), 0, 3.14, 2)
            pygame.draw.arc(surf, c, (40, 40, 10, 10), 0, 3.14, 2)

        return surf

    @staticmethod
    def draw_particle(kind="dust") -> pygame.Surface:
        surf = AssetGenerator._create_surface(PARTICLE_SIZE)
        if kind == "dust":
            # Soft cloud
            pygame.draw.circle(surf, (240, 240, 240, 150), (16, 16), 8)
        elif kind == "spark":
            # Diamond shape star
            c = PALETTE["gold"]
            pygame.draw.line(surf, c, (16, 8), (16, 24), 2)
            pygame.draw.line(surf, c, (8, 16), (24, 16), 2)
            pygame.draw.circle(surf, (255, 255, 255), (16, 16), 2)
        
        return surf

    @classmethod
    def generate_all_and_save(cls):
        """Generate all defined assets and save to disk."""
        if not os.path.exists(ASSET_DIR):
            os.makedirs(ASSET_DIR)
            print(f"Created asset directory: {ASSET_DIR}")

        tasks = [
            ("crop_carrot_stage1", lambda: cls.draw_carrot(1)),
            ("crop_carrot_stage2", lambda: cls.draw_carrot(2)),
            ("crop_carrot_stage3", lambda: cls.draw_carrot(3)),
            ("crop_carrot_stage4", lambda: cls.draw_carrot(4)),
            
            ("crop_pumpkin_stage1", lambda: cls.draw_pumpkin(1)),
            ("crop_pumpkin_stage2", lambda: cls.draw_pumpkin(2)),
            ("crop_pumpkin_stage3", lambda: cls.draw_pumpkin(3)),
            ("crop_pumpkin_stage4", lambda: cls.draw_pumpkin(4)),

            ("crop_sunflower_stage1", lambda: cls.draw_sunflower(1)),
            ("crop_sunflower_stage2", lambda: cls.draw_sunflower(2)),
            ("crop_sunflower_stage3", lambda: cls.draw_sunflower(3)),
            ("crop_sunflower_stage4", lambda: cls.draw_sunflower(4)),

            ("shrub_dead", cls.draw_shrub_dead),
            
            ("drone_idle", lambda: cls.draw_drone("idle")),
            ("drone_working", lambda: cls.draw_drone("working")),
            
            ("tile_dirt", lambda: cls.draw_tile("dirt")),
            ("tile_wet", lambda: cls.draw_tile("wet")),
            ("tile_grass", lambda: cls.draw_tile("grass")),
            
            ("particle_dust", lambda: cls.draw_particle("dust")),
            ("particle_spark", lambda: cls.draw_particle("spark")),
        ]

        print("Generating Assets V2 (High Fidelity)...")
        for name, func in tasks:
            path = os.path.join(ASSET_DIR, f"{name}.png")
            try:
                surf = func()
                pygame.image.save(surf, path)
                print(f"  [OK] {name}.png")
            except Exception as e:
                print(f"  [ERR] {name} - {e}")

if __name__ == "__main__":
    AssetGenerator.generate_all_and_save()
